
---
title: <Topic Title> — Interactive Curriculum
tags: [<tag1>, <tag2>, <tag3>]
updated: 2025-08-09
---

## Overview
One or two sentences on what this curriculum covers and who it’s for.

## Learning Outcomes
- Outcome 1
- Outcome 2
- Outcome 3

## How to Use This Guide
- Engage an AI Teacher. Ask questions. Do the activities. Reflect briefly.
- Time per phase: 20–30 minutes.

## Phase 1 — <Title>
**Goal:** What success looks like.  
**Core Ideas:** bullet points only.  
**Ask the AI Teacher:** 2–3 prompts in natural language.  
**Activity (no code):** a short practice task learners can describe/plan.  
**Reflect:** one question to self-assess.

## Phase 2 — <Title>
(repeat the same structure)

## Final Project
- Small capstone that stitches phases together.
- Deliverables: short write-up, architecture sketch, lessons learned.

## Further Study
- 3–5 bullets pointing to next steps.
