
# Lesson Checklist

- Read the “Core Ideas”
- Ask at least one AI Teacher prompt
- Do the activity (plan or describe steps)
- Write a 3-bullet reflection (insight, friction, next step)
