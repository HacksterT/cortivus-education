
# Learning GCP Infrastructure as Code — What I’m Learning This Month

Many people ask how to learn AI or cloud without getting lost. I put together an interactive curriculum for **GCP Infrastructure as Code** you can reuse: short phases, prompts to ask an AI Teacher, and small activities you can do in 20–30 minutes.

**What’s inside**
- Foundations of GCP and IaC
- GCP Deployment Manager (native)
- Terraform on GCP (industry standard)
- Automation with Cloud Build
- A small final project to tie it together

Use it as-is or adapt it to your stack. If you try it, tell me what worked and what to improve.

_Hashtags:_ #LearningInPublic #GCP #Terraform #DevOps #Cloud
