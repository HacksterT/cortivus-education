
---
title: Learning GCP Infrastructure as Code — Interactive Curriculum
tags: [gcp, iac, terraform, cloud, devops, education]
updated: 2025-08-09
---

## Overview
Learn Google Cloud Platform (GCP) Infrastructure as Code (IaC) through short, guided phases. You’ll engage an AI Teacher, ask targeted questions, and complete small, no-code activities to internalize concepts.

## Learning Outcomes
- Explain IaC and its benefits in GCP
- Describe GCP’s core building blocks (Projects, IAM, VPC, Compute, Storage)
- Compare GCP Deployment Manager and Terraform at a high level
- Outline an automated IaC workflow with Cloud Build
- Draft a small production-like deployment plan

## How to Use This Guide
- Work in 20–30 minute sessions.  
- For each phase: read Core Ideas → ask the AI Teacher → do the Activity → Reflect.

---

## Phase 1 — Foundations of GCP & IaC
**Goal:** Understand basic GCP concepts and IaC fundamentals.

**Core Ideas**
- GCP resources live inside Projects; access via IAM; networking via VPC
- IaC defines infrastructure in files and deploys automatically
- Benefits: automation, consistency, repeatability

**Ask the AI Teacher**
- “Explain GCP’s core building blocks and give me simple analogies for each.”
- “What changes when teams move from manual setup to Infrastructure as Code?”

**Activity (no code)**
- Write a paragraph describing how you might set up a simple website manually in GCP. Then list how IaC would streamline each step.

**Reflect**
- What parts of manual setup are most error-prone, and how would IaC reduce that risk?

---

## Phase 2 — GCP’s Native IaC: Deployment Manager
**Goal:** Learn the basics of GCP’s built-in IaC tool.

**Core Ideas**
- Declarative configs describe the desired end state
- YAML configs, optional templates for reuse
- Create, update, and delete deployments reproducibly

**Ask the AI Teacher**
- “Walk me through creating a simple VM using Deployment Manager. What are the moving parts?”
- “When would templates be helpful, and how do they differ from plain YAML?”

**Activity (no code)**
- Outline resources for a tiny environment (VM, firewall rule, storage). Sketch how they relate (bullet list or boxes/arrows).

**Reflect**
- Where would parameters or templates reduce duplication in your outline?

---

## Phase 3 — Industry Standard IaC: Terraform with GCP
**Goal:** Understand Terraform’s workflow and concepts in the GCP context.

**Core Ideas**
- Providers/resources map to GCP APIs
- Workflow: init → plan → apply → destroy
- Variables, outputs, and modules enable reuse and composition

**Ask the AI Teacher**
- “Explain Terraform’s workflow step-by-step using GCP as the platform.”
- “What’s the difference between Terraform modules and Deployment Manager templates?”

**Activity (no code)**
- Make a checklist of 5–7 GCP resources you’d provision for a small app. Next to each, jot how IaC helps manage it over time (naming, tagging, updates).

**Reflect**
- Which resources benefit most from being codified, and why?

---

## Phase 4 — Automation with Cloud Build
**Goal:** Connect IaC to CI/CD for repeatable, auditable deployments.

**Core Ideas**
- Cloud Build can run plans/applies on commit
- Remote state in GCS prevents conflicts for teams
- Secrets should be stored and referenced securely

**Ask the AI Teacher**
- “How do I trigger Terraform in Cloud Build on each push to main, safely?”
- “What are best practices for storing state and secrets in GCP?”

**Activity (no code)**
- Describe a scenario with two collaborators making changes. Identify where conflicts could happen and how remote state + approvals would mitigate them.

**Reflect**
- What governance or review steps would you include before production applies?

---

## Phase 5 — Complex & Multi-Service Deployments
**Goal:** Think through production-grade patterns.

**Core Ideas**
- Separate dev/staging/prod with clear boundaries
- Networking, security, and identity are first-class
- Policy as code and guardrails reduce risk

**Ask the AI Teacher**
- “Propose a simple production architecture in GCP that IaC can provision end-to-end.”
- “How can observability (logs/metrics) be integrated into the IaC plan?”

**Activity (no code)**
- Draft a high-level diagram (or bullet list) for a 3-tier app (front-end, API, data). Note which parts change per environment and which stay constant.

**Reflect**
- Where are your biggest risks (cost, security, resilience), and how would IaC controls address them?

---

## Final Project
- Choose one capstone:
  - Simple web app (VM + storage + firewall)
  - Basic data pipeline (Pub/Sub + Cloud Function + Storage)
- **Deliverables:** one-page architecture note, list of IaC resources, and three lessons learned.

## Further Study
- Compare approaches on AWS and Azure
- Explore Terragrunt or policy-as-code (Sentinel/OPA)
- Add cost estimation and drift detection to your workflow
